const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const cors = require("cors"); // Require the cors package
const bodyParser = require("body-parser");

const app = express();
const port = 4000;

app.use(cors()); // Enable CORS for all routes
app.use(bodyParser.json({ limit: "50mb" })); // Increase the limit if needed

// Configure multer for handling file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, "uploads");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir);
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(
      null,
      file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname)
    );
  },
});

const upload = multer({ storage: storage });

// Serve static files from the 'uploads' directory
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Handle image upload
app.post("/api/upload-image", upload.single("UploadFiles"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No image file uploaded.");
  }

  const imageUrl = `http://localhost:${port}/uploads/${req.file.filename}`;
  res.json({ imageUrl });
});

// Handle file upload
app.post("/api/upload-file", upload.single("fileUpload"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No image file uploaded.");
  }

  const fileName = req.file.filename;
  res.json({ fileName });
});

//handle edited image file upload
app.post("/api/upload-edited-image", (req, res) => {
  try {
    const { imageData } = req.body;

    if (!imageData) {
      return res.status(400).send("Filename and image data are required.");
    }

    const filename =
      "editedImage-" +
      Date.now() +
      "-" +
      Math.round(Math.random() * 1e9) +
      ".png";

    // Define the file path
    const filePath = path.join(__dirname, "uploads", filename);

    // Write the buffer to a file
    fs.writeFile(filePath, imageData, { encoding: "base64" }, (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error saving the image.");
      }
      res.send({ imageUrl: `http://localhost:${port}/uploads/${filename}` });
    });
  } catch (error) {
    console.log("error", error);
    res.status(500).send("Internal server error.");
  }
});

// DELETE endpoint to remove an image file
app.delete("/api/delete-image/:filename", (req, res) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, "uploads", filename);

    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error deleting the image.");
      }
      res.send("Image deleted successfully.");
    });
  } catch (error) {
    console.log("error", error);
  }
});

app.delete("/api/delete-file/:filename", (req, res) => {
  try {
    const filename = req.params.filename;
    console.log("filename:", filename);
    const filePath = path.join(__dirname, "uploads", filename);

    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error deleting the image.");
      }
      res.send("Image deleted successfully.");
    });
  } catch (error) {
    console.log("error", error);
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
