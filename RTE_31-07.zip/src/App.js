import React from "react";
import MyRTE from "./component/MyRTE";

function App() {
  const generateHTML = (startIndex, count) => {
    let html = `<ol><li><strong>This is&nbsp; bold testing</strong></li><li><h1><strong><em>This is Heading 1 testing</em></strong></h1></li><li><h2 style="text-align: center;">This is heading 2 testing</h2></li><li><div><span style="text-decoration: underline;"><em><strong>This is bold + italic + underline testing</strong></em></span></div></li></ol>`;
    for (let i = 0; i < count; i++) {
      const imageNumber = startIndex + i;
      html += `<p><img src="http://localhost:4000/5_mb/image_copy_${String(
        imageNumber
      ).padStart(
        3,
        "0"
      )}.jpg" class="e-rte-image e-imginline" width="auto" height="auto" style="min-width: 0px; max-width: 1101px; min-height: 0px; opacity: 1;"></p>`;
    }
    html =
      html +
      `<ol><li><strong>This is&nbsp; bold testing</strong></li><li><h1><strong><em>This is Heading 1 testing</em></strong></h1></li><li><h2 style="text-align: center;">This is heading 2 testing</h2></li><li><div><span style="text-decoration: underline;"><em><strong>This is bold + italic + underline testing</strong></em></span></div></li></ol>`;

    // for (let i = 0; i < count - 10; i++) {
    //   const imageNumber = startIndex + i;
    //   html += `<p><img src="http://localhost:4000/uploads/image_copy_${String(
    //     imageNumber
    //   ).padStart(
    //     3,
    //     "0"
    //   )}.jpg" class="e-rte-image e-imginline" width="auto" height="auto" style="min-width: 0px; max-width: 1101px; min-height: 0px; opacity: 1;"></p>`;
    // }

    return html;
  };

  const generateMultipleHTML = (totalHTML, imagesPerHTML) => {
    const htmlStrings = [];
    let currentIndex = 1;
    for (let i = 0; i < totalHTML; i++) {
      htmlStrings.push(generateHTML(currentIndex, imagesPerHTML));
      currentIndex += imagesPerHTML;
    }
    return htmlStrings;
  };

  const htmlStrings = generateMultipleHTML(15, 20);
  // console.log("htmlStrings:", htmlStrings);

  return (
    <>
      {htmlStrings.map((html, index) => (
        <MyRTE key={index} index={index} HTML={""} />
      ))}
    </>
  );
}

export default App;
