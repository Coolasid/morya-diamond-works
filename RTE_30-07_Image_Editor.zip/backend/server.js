const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const cors = require("cors"); // Require the cors package

const app = express();
const port = 4000;

app.use(cors()); // Enable CORS for all routes

// Configure multer for handling file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, "uploads");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir);
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(
      null,
      file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname)
    );
  },
});

const upload = multer({ storage: storage });

// Serve static files from the 'uploads' directory
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Handle image upload
app.post("/api/upload-image", upload.single("UploadFiles"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No image file uploaded.");
  }

  const imageUrl = `http://localhost:${port}/uploads/${req.file.filename}`;
  res.json({ imageUrl });
});

// Handle file upload
app.post("/api/upload-file", upload.single("fileUpload"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No image file uploaded.");
  }

  const fileName = req.file.filename;
  res.json({ fileName });
});

// // Configure multer for handling file uploads
// // const storage = multer.diskStorage({
// //   destination: (req, file, cb) => {
// //     const uploadDir = path.join(__dirname, "5_mb");
// //     if (!fs.existsSync(uploadDir)) {
// //       fs.mkdirSync(uploadDir);
// //     }
// //     cb(null, uploadDir);
// //   },
// //   filename: (req, file, cb) => {
// //     const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
// //     cb(
// //       null,
// //       file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname)
// //     );
// //   },
// // });

// // const upload = multer({ storage: storage });

// // Serve static files from the 'uploads' directory
// app.use("/images", express.static(path.join(__dirname, "Images")));

// // Handle image upload
// const upload = multer({ dest: "Images/" });

// app.post("/api/upload-image", upload.single("UploadFiles"), (req, res) => {
//   try {
//     const httpPostedFile = req.file;
//     let imageFile = httpPostedFile.originalname;

//     if (httpPostedFile) {
//       const fileSave = path.join(__dirname, "Images");
//       if (!fs.existsSync(fileSave)) {
//         fs.mkdirSync(fileSave);
//       }

//       let fileName = path.basename(httpPostedFile.originalname);
//       let fileSavePath = path.join(fileSave, fileName);
//       let x = 1;

//       while (fs.existsSync(fileSavePath)) {
//         imageFile = `rteImage${x}-${fileName}`;
//         fileSavePath = path.join(fileSave, imageFile);
//         x++;
//       }

//       if (!fs.existsSync(fileSavePath)) {
//         fs.renameSync(httpPostedFile.path, fileSavePath);
//         res.setHeader("name", imageFile);
//         res.status(200).json({ message: "File uploaded successfully" });
//       }
//     }
//   } catch (e) {
//     res.status(204).json({ message: e.message });
//   }
// });

// DELETE endpoint to remove an image file
app.delete("/api/delete-image/:filename", (req, res) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, "uploads", filename);

    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error deleting the image.");
      }
      res.send("Image deleted successfully.");
    });
  } catch (error) {
    console.log("error", error);
  }
});

app.delete("/api/delete-file/:filename", (req, res) => {
  try {
    const filename = req.params.filename;
    console.log("filename:", filename);
    const filePath = path.join(__dirname, "uploads", filename);

    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Error deleting the image.");
      }
      res.send("Image deleted successfully.");
    });
  } catch (error) {
    console.log("error", error);
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
