import React, { useRef, useCallback, useState } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

const RichTextEditor = () => {
  const quillRef = useRef(null);
  const [content, setContent] = useState("");
  const [error, setError] = useState(null);

  const modules = {
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ["bold", "italic", "underline", "strike"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link", "image"],
      ["clean"],
    ],
    clipboard: {
      matchVisual: false,
    },
  };

  const formats = [
    "header",
    "bold",
    "italic",
    "underline",
    "strike",
    "list",
    "bullet",
    "link",
    "image",
  ];

  const handleImageUpload = useCallback(async (file) => {
    const formData = new FormData();
    formData.append("image", file);

    try {
      const response = await fetch("http://localhost:4000/api/upload-image", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Image upload failed");
      }

      const data = await response.json();
      return data.imageUrl;
    } catch (error) {
      console.error("Error uploading image:", error);
      setError("Failed to upload image. Please try again.");
      return null;
    }
  }, []);

  const handlePaste = useCallback(
    async (event) => {
      const clipboard = event.clipboardData || window.clipboardData;
      const items = clipboard.items;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf("image") !== -1) {
          event.preventDefault();
          const file = items[i].getAsFile();
          const imageUrl = await handleImageUpload(file);

          if (imageUrl) {
            const quill = quillRef.current.getEditor();
            const range = quill.getSelection(true);
            quill.insertEmbed(range.index, "image", imageUrl);
          }
          break;
        }
      }
    },
    [handleImageUpload]
  );

  const handleChange = (value) => {
    setContent(value);
  };

  const handleRetrieveContent = () => {
    console.log("Editor content:", content);
    // Here you can do something with the content, like sending it to a server
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <ReactQuill
        ref={quillRef}
        value={content}
        onChange={handleChange}
        modules={modules}
        formats={formats}
        onPaste={handlePaste}
        className="h-64 mb-4"
      />
      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      <Button onClick={handleRetrieveContent}>Retrieve Content</Button>
    </div>
  );
};

export default RichTextEditor;
