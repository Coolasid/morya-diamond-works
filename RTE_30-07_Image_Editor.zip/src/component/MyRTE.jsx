import React, { useRef, useEffect } from "react";
import {
  RichTextEditorComponent,
  Toolbar,
  Image,
  Link,
  HtmlEditor,
  QuickToolbar,
  Inject,
  PasteCleanup,
  MsWordPaste,
  FileManager,
  Resize,
  Table,
  MarkdownEditor,
  FormatPainter,
  NodeSelection,
} from "@syncfusion/ej2-react-richtexteditor";
import { UploaderComponent } from "@syncfusion/ej2-react-inputs/src/uploader";

import "../App.css";
import axios from "axios";
import { registerLicense } from "@syncfusion/ej2-base";
import pdfImage from "../images/pdfIcon.png";
import zipImage from "../images/zipImage.png";
import { DialogComponent } from "@syncfusion/ej2-react-popups";
import { ImageEditorComponent } from "@syncfusion/ej2-react-image-editor";
import CustomDialogComponent from "./DialogComponent";
registerLicense(
  "Ngo9BigBOggjHTQxAR8/V1NCaF1cWWhBYVFyWmFZfVpgdl9GaVZSR2YuP1ZhSXxXdkJhXH9ccH1WQmhcUUM="
);

const MyRTE = ({ HTML, index }) => {
  let rteObj;
  const [value, setValue] = React.useState("");
  // const [range, setRange] = React.useState(null);
  // const [saveSelection, ] = React.useState(null);

  let uploadObj;
  let selection = new NodeSelection();
  let range;
  let saveSelection;
  let dropElement;
  const dlgButtons = [
    {
      buttonModel: { content: "Insert", isPrimary: true },
      click: onInsert.bind(this),
    },
    { buttonModel: { content: "Cancel" }, click: onCancel },
  ];
  const header = "Image Editor";
  var dialogObj;
  var imageEditorObj;
  // var rteObj;
  // var range;
  // var saveSelection;
  var dataURL;
  var isLoaded = false;

  function onInsert(args) {
    console.log("args:", args);
    console.log("inside insert");
    if (rteObj.formatter.getUndoRedoStack().length === 0) {
      rteObj.formatter.saveData();
    }
    saveSelection.restore();
    var canvas = document.createElement("CANVAS");
    var ctx = canvas.getContext("2d");
    const imgData = imageEditorObj.getImageData();
    console.log("imgData:", imgData);
    console.log("imageEditorObj:", imageEditorObj);
    // return;
    canvas.height = imgData.height;
    canvas.width = imgData.width;
    ctx.putImageData(imgData, 0, 0);
    isLoaded = true;
    rteObj.executeCommand("editImage", {
      url: canvas.toDataURL(),
      width: { width: canvas.width },
      height: { height: canvas.height },
      selection: saveSelection,
    });

    rteObj.formatter.saveData();
    rteObj.formatter.enableUndo(rteObj);

    dialogObj.hide();
  }

  function onCancel() {
    console.log("inside cancel");
    console.log("imageEditorObj:", imageEditorObj);

    dialogObj.hide();
  }
  function onToolbarClick(args) {
    if (args.item.tooltipText === "Image Editor") {
      imageEditorObj.imgSrc = null;
      console.log("imageEditorObj:", imageEditorObj);
      // imageEditorObj.drawModule.openURL = null;
      console.log("inside image editor");
      range = selection.getRange(document);
      console.log("range:", range);
      saveSelection = selection.save(range, document);
      console.log("saveSelection:", saveSelection);
      dialogObj.show();
    }
  }
  function OnBeforeOpen(args) {
    console.log("args before open:", args);
    console.log("inside before open");
    var imageELement;
    console.log("range:", range);
    var selectNodes =
      rteObj.formatter.editorManager.nodeSelection.getNodeCollection(range);
    console.log("selectNodes:", selectNodes);
    if (selectNodes.length == 1 && selectNodes[0].tagName == "IMG") {
      imageELement = selectNodes[0];
      imageELement.crossOrigin = "anonymous";
      var canvas = document.createElement("CANVAS");
      var ctx = canvas.getContext("2d");
      console.log("ctx:", ctx);
      canvas.height = imageELement.offsetHeight;
      canvas.width = imageELement.offsetWidth;
      console.log("canvas:", canvas);

      // Force the image to reload by setting its src to a new value
      var originalSrc = imageELement.src;
      imageELement.src = "";
      imageELement.src = originalSrc;

      imageELement.onload = function () {
        console.log("imageELement.onload:", imageELement.onload);
        ctx.drawImage(imageELement, 0, 0, canvas.width, canvas.height);
        dataURL = canvas.toDataURL();
        // if (!isLoaded) {
        imageEditorObj.open(dataURL);
        // }
      };
    }
  }

  const afterImageDelete = (arg) => {
    console.log("arg_remove:", arg);
    const imageName = arg.src.split("/").pop();
    console.log("imageName:", imageName);
    axios
      .delete("http://localhost:4000/api/delete-image/" + imageName)
      .then((response) => {
        console.log("File deleted successfully:", response);
      })
      .catch((error) => {
        console.error("Error deleting file:", error);
      });
  };

  const onFileRemove = (arg) => {
    console.log("arg_remove:", arg);
    const fileName = arg.filesData[0].name;
    console.log("fileName:", fileName);
    // Delete the file from the server
    axios
      .delete("http://localhost:4000/api/delete-file/" + fileName)
      .then((response) => {
        console.log("File deleted successfully:", response);

        // Remove the link from the RTE content
        const rteContent = rteObj.contentModule.getEditPanel();
        console.log("rteContent:", rteContent);
        const links = rteContent.getElementsByTagName("a");
        console.log("links:", links);

        for (let link of links) {
          if (link.href.includes(fileName)) {
            link.parentNode.removeChild(link);
            break;
          }
        }

        // Save the changes to the RTE content
        rteObj.formatter.saveData();
        rteObj.formatter.enableUndo(rteObj);
      })
      .catch((error) => {
        console.error("Error deleting file:", error);
      });
  };

  const toolbarSettings = {
    items: [
      "Bold",
      "Italic",
      "Underline",
      "StrikeThrough",
      "FontName",
      "FontSize",
      // "FontColor",
      // "BackgroundColor",
      "LowerCase",
      "UpperCase",
      "|",
      "Formats",
      "Alignments",
      "OrderedList",
      "UnorderedList",
      "Outdent",
      "Indent",
      "|",
      "CreateLink",
      "Image",
      "|",
      "ClearFormat",
      "Print",
      "SourceCode",
      "FullScreen",
      "|",
      "Undo",
      "Redo",
    ],
  };
  const quickToolbarSettings = {
    image: [
      "Replace",
      "Align",
      "Caption",
      "Remove",
      "-",
      "InsertLink",
      "OpenImageLink",
      "EditImageLink",
      "RemoveImageLink",
      "Display",
      "AltText",
      {
        tooltipText: "Image Editor",
        template:
          "<button class='e-tbar-btn e-btn' id='imageEditor'><span class='e-btn-icon e-icons e-rte-image-editor'></span>",
      },
    ],
    link: ["Open", "Edit", "UnLink"],
  };

  useEffect(() => {
    setValue(HTML);
  }, [HTML]);

  function onImageUploadSuccess(args) {
    if (JSON.parse(args.e.currentTarget.response)?.imageUrl != null) {
      const serverUrl = JSON.parse(args.e.currentTarget.response)?.imageUrl;

      if (args.detectImageSource !== "Uploaded") {
        args.file.name = "/" + serverUrl.split("/").pop();
      } else {
        args.file.name = "/" + serverUrl.split("/").pop();
        let filename = document.querySelectorAll(".e-file-name")[0];
        filename.title = args.file.name;
      }
    }
  }

  const asyncSettings = {
    saveUrl: "http://localhost:4000/api/upload-file",
    path: "",
    // removeUrl: "http://localhost:4000/api/delete-files",
  };

  function onUploadSuccess(args) {
    console.log("args:", args);
    rteObj.contentModule.getEditPanel().focus();
    range = selection.getRange(document);
    saveSelection = selection.save(range, document);
    args.file.name = JSON.parse(args.e.currentTarget.response).fileName;
    var fileUrl =
      rteObj.insertImageSettings.path +
      "/" +
      JSON.parse(args.e.currentTarget.response).fileName;
    if (rteObj.formatter.getUndoRedoStack().length === 0) {
      rteObj.formatter.saveData();
    }
    saveSelection.restore();
    const fileElement = `<a href="${fileUrl}" target="_blank">${fileUrl}</a>`;

    rteObj.executeCommand("insertHTML", fileElement);

    rteObj.formatter.saveData();
    rteObj.formatter.enableUndo(rteObj);
    // uploadObj.clearAll();
    console.log("rteObj:", rteObj);
  }

  return (
    <div className='control-pane'>
      <div className='col-lg-8 '>
        <div className='control-section' id='rteAPI'>
          <button
            style={{ margin: "25px 10px 10px 10px", padding: "5px" }}
            onClick={() => {
              if (rteObj) {
                console.log(rteObj.getHtml());
              }
            }}
          >
            get rtf
          </button>
          <h4>Rich Text Editor {index + 1}</h4>
          <div className='rte-control-section'>
            <RichTextEditorComponent
              toolbarClick={onToolbarClick}
              ref={(richtexteditor) => {
                rteObj = richtexteditor;
              }}
              value={value}
              toolbarSettings={toolbarSettings}
              quickToolbarSettings={quickToolbarSettings}
              id='PasteCleanup'
              pasteCleanupSettings={{
                plainText: false,
                keepFormat: false,
              }}
              insertImageSettings={{
                saveUrl: "http://localhost:4000/api/upload-image",
                path: "http://localhost:4000/uploads",
              }}
              beforeImageUpload={(arg) => {
                arg.currentRequest = {
                  Authorization: "Bearer YOUR",
                };
              }}
              afterImageDelete={afterImageDelete}
              imageUploadSuccess={onImageUploadSuccess}

              // delayUpdate={1000}
              // autoSaveOnIdle={true}
              // saveInterval={1000}
            >
              <Inject
                services={[
                  Toolbar,
                  Image,
                  Link,
                  HtmlEditor,
                  QuickToolbar,
                  PasteCleanup,
                  FileManager,
                  Resize,
                  Table,
                  Resize,
                  Table,
                  MarkdownEditor,
                  FormatPainter,
                ]}
              />
            </RichTextEditorComponent>
            <UploaderComponent
              id='fileUpload'
              type='file'
              ref={(scope) => {
                uploadObj = scope;
              }}
              asyncSettings={asyncSettings}
              dropArea={dropElement}
              success={onUploadSuccess.bind(this)}
              showFileList={true}
              maxFileSize={10000000000}
              removing={onFileRemove.bind(this)}
              // autoUpload={true}
            ></UploaderComponent>
            <DialogComponent
              id='ImageEditorDialog'
              ref={(scope) => {
                dialogObj = scope;
              }}
              buttons={dlgButtons}
              beforeOpen={OnBeforeOpen}
              header={header}
              visible={false}
              showCloseIcon={true}
              width='800px'
              height='800px'
              isModal={true}
            >
              <div className='dialogContent'>
                <ImageEditorComponent
                  height='500px'
                  ref={(scope) => {
                    imageEditorObj = scope;
                  }}
                />
              </div>
            </DialogComponent>
            {/* <CustomDialogComponent dialogObj={dialogObj} rteObj={rteObj} /> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyRTE;
