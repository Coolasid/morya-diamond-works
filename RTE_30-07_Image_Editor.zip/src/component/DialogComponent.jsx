// import { ImageEditorComponent } from "@syncfusion/ej2-react-image-editor";
// import { DialogComponent } from "@syncfusion/ej2-react-popups";
// import { NodeSelection } from "@syncfusion/ej2-react-richtexteditor";
// import React from "react";

// const CustomDialogComponent = ({ rteObj, dialogObj }) => {
//   let uploadObj;
//   let selection = new NodeSelection();
//   let range;
//   let saveSelection;
//   let dropElement;
//   const dlgButtons = [
//     {
//       buttonModel: { content: "Insert", isPrimary: true },
//       click: onInsert.bind(this),
//     },
//     { buttonModel: { content: "Cancel" }, click: onCancel },
//   ];
//   // const selection = new NodeSelection();
//   const header = "Image Editor";
//   //   var dialogObj;
//   var imageEditorObj;
//   // var rteObj;
//   // var range;
//   // var saveSelection;
//   var dataURL;
//   var isLoaded = false;

//   function onInsert(args) {
//     console.log("args:", args);
//     console.log("inside insert");
//     if (rteObj.formatter.getUndoRedoStack().length === 0) {
//       rteObj.formatter.saveData();
//     }
//     saveSelection.restore();
//     var canvas = document.createElement("CANVAS");
//     var ctx = canvas.getContext("2d");
//     const imgData = imageEditorObj.getImageData();
//     console.log("imgData:", imgData);
//     console.log("imageEditorObj:", imageEditorObj);
//     canvas.height = imgData.height;
//     canvas.width = imgData.width;
//     ctx.putImageData(imgData, 0, 0);
//     isLoaded = true;
//     rteObj.executeCommand("editImage", {
//       url: canvas.toDataURL(),
//       width: { width: canvas.width },
//       height: { height: canvas.height },
//       selection: saveSelection,
//     });
//     rteObj.formatter.saveData();
//     rteObj.formatter.enableUndo(rteObj);
//     dialogObj.hide();
//   }

//   function onCancel() {
//     console.log("inside cancel");
//     console.log("imageEditorObj:", imageEditorObj);
//     dialogObj.hide();
//   }
//   //   function onToolbarClick(args) {
//   //     imageEditorObj.imageData = null;

//   //     if (args.item.tooltipText === "Image Editor") {
//   //       console.log("inside image editor");
//   //       range = selection.getRange(document);
//   //       console.log("range:", range);
//   //       saveSelection = selection.save(range, document);
//   //       console.log("saveSelection:", saveSelection);
//   //       dialogObj.show();
//   //     }
//   //   }
//   function OnBeforeOpen(args) {
//     console.log("args before open:", args);
//     console.log("inside before open");
//     var imageELement;
//     var selectNodes =
//       rteObj.formatter.editorManager.nodeSelection.getNodeCollection(range);
//     if (selectNodes.length == 1 && selectNodes[0].tagName == "IMG") {
//       imageELement = selectNodes[0];
//       imageELement.crossOrigin = "anonymous";
//       var canvas = document.createElement("CANVAS");
//       var ctx = canvas.getContext("2d");
//       canvas.height = imageELement.offsetHeight;
//       canvas.width = imageELement.offsetWidth;
//       imageELement.onload = function () {
//         ctx.drawImage(imageELement, 0, 0, canvas.width, canvas.height);
//         dataURL = canvas.toDataURL();
//         if (!isLoaded) {
//           imageEditorObj.open(dataURL);
//         }
//       };
//     }
//   }
//   return (
//     <DialogComponent
//       id='ImageEditorDialog'
//       ref={(scope) => {
//         dialogObj = scope;
//       }}
//       buttons={dlgButtons}
//       beforeOpen={OnBeforeOpen}
//       header={header}
//       visible={false}
//       showCloseIcon={true}
//       width='800px'
//       height='800px'
//       isModal={true}
//     >
//       <div className='dialogContent'>
//         <ImageEditorComponent
//           height='500px'
//           ref={(scope) => {
//             imageEditorObj = scope;
//           }}
//         />
//       </div>
//     </DialogComponent>
//   );
// };

// export default CustomDialogComponent;
